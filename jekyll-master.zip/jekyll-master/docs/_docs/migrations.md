---
title: Blog Migrations
permalink: /docs/migrations/
---

If you’re switching to Jekyll from another blogging system, Jekyll’s importers
can help you with the move. To learn more about importing your site to Jekyll,
visit our [`jekyll-import` docs site](https://import.jekyllrb.com/docs/home/).
