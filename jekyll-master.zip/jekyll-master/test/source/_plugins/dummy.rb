# frozen_string_literal: true

module Jekyll
  class Dummy < Generator
    priority :high

    def generate(site) end
  end
end
