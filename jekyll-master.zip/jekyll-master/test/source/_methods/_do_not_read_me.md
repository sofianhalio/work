---
title: The unreadable wonder
---

Don't read me, you fool! FILTER ME
